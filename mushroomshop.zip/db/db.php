<?php

$connect = new PDO(
  'mysql:host=localhost;dbname=mushroomshop;charset=utf8',
  'root',
  ''
);
